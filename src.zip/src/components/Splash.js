//Import nav and css for the page
import React, { useState,useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './Splash.css';
//Import images to use
import mainImage from './user.png';
import p1 from './p1.png';
import p2 from './p2.png';
import p3 from './p3.png';
import p4 from './p4.png';
import p5 from './p5.png';
import p6 from './p6.png';

//Functional component
const Splash = () => {
    const navigate = useNavigate();//Allows for navigation
    const defaultLocation = localStorage.getItem('userLocation') || 'London';
    const [location, setLocation] = useState(defaultLocation);
    const [inputValue, setInputValue] = useState('');
    //Names array
    const names = ["Alex", "Jordan", "Taylor", "Casey", "Morgan", "Charlie"];
    //Array of patient objects each patient has a name, image, and navigation route
    //Nav to userWeatherA = Arthritis , userWeatherH = Heart Disease, userWeatherN = Neurological Condition
    //userWeatherR=Respiratory Illness, userWeatherS=Stroke Victim
    const patients = [
        { name: names[0], image: p1, weatherPage: '/UserWeatherA' },
        { name: names[1], image: p2, weatherPage: '/UserWeatherH' },
        { name: names[2], image: p3, weatherPage: '/UserWeatherN' },
        { name: names[3], image: p4, weatherPage: '/UserWeatherR' },
        { name: names[4], image: p5, weatherPage: '/UserWeatherS' },
        { name: names[5], image: p6, weatherPage: '/UserWeatherA' },
    ];

    const handleInputChange = (e) => {
        setInputValue(e.target.value);
    };

    const updateLocation = () => {
        setLocation(inputValue); // Update location with new input
        localStorage.setItem('userLocation', inputValue); // Store location in local storage
        setInputValue(''); // Clear input field
    };


    //JSX code for page rendering
    return (

        <div className="container">
            <div className="searchBarContainer">
                <input
                    className="searchBar"
                    type="text"
                    placeholder={`Current location set to ${location}`}
                    value={inputValue}
                    onChange={handleInputChange}
                />
                <button className="updateLocationBtn" onClick={updateLocation}>Update</button>
            </div>

            <div className="greeting">Good Morning Julie</div>
            <div className="mainCircle">
                <img src={mainImage} alt="Center Piece" style={{width: '100%', height: 'auto'}}/>
            </div>
            <div className="selectPatient">Select a patient</div>
            <div className="patientsGrid">
                {patients.map((patient, index) => (
                    <div key={index} className="patientItem" onClick={() => navigate(patient.weatherPage)}>
                        <img src={patient.image} alt={patient.name} className="patientCircle"/>
                        <div className="patientName">{patient.name}</div>
                    </div>
                ))}
            </div>
            <button className="registerPatientBtn" onClick={() => navigate('/Patient')}>Register a Patient</button>
        </div>
    );
};

export default Splash;
