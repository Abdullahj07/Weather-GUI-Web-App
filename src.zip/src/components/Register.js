//Import components to navigate
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
//Import Register.css to allow styling
import './Register.css';

//Defines the caretaker registration component
function CaretakerRegistration() {
    const [formData, setFormData] = useState({
        //Initializes the input fields for the caretaker
        fullName: '',
        username: '',
        gender: '',
        birthDate: '',
        email: '',
        phonePrefix: '+44',
        phoneNumber: '',
        password: '',
    });
    //State used to display a success message one submit
    const [showSuccessMessage, setShowSuccessMessage] = useState(false);
    //Hook to allow navigation to navigable places
    const navigate = useNavigate();
    //Handle changes and edit form data
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prevState => ({
            ...prevState,
            [name]: value
        }));
    };
    //Handle summit prevent default action and navigates to the login page after 2
    // seconds so user can see success message
    const handleSubmit = (event) => {
        event.preventDefault();
        console.log(formData);//Show form data for testing
        setShowSuccessMessage(true);//Show success message
        setTimeout(() => navigate('/login'), 2000);//Redirect to login page
    };
//Render markup for registration form page
    return (
        <div className="caretaker-container">
            <div className="caretaker-formContainer">
                <div className="caretaker-titleContainer">
                    <div className="caretaker-title caretaker-green"><i>Green</i>Go</div>
                    <div className="caretaker-title caretaker-red"><i>Red</i>No</div>
                </div>
                {showSuccessMessage && <div className="caretaker-successMessage">Registration successful! Redirecting to login...</div>}
                <form onSubmit={handleSubmit}>
                    <div className="caretaker-inputRow">
                        <input
                            className="caretaker-inputField"
                            placeholder="Enter Full Name"
                            name="fullName"
                            value={formData.fullName}
                            onChange={handleChange}
                        />
                    </div>
                    <div className="caretaker-inputRow">
                        <input
                            className="caretaker-inputField"
                            placeholder="Enter Username"
                            name="username"
                            required
                            value={formData.username}
                            onChange={handleChange}
                        />
                    </div>
                    <div className="caretaker-inputRow caretaker-genderRow">
                        <div className={`caretaker-genderOption ${formData.gender === 'Male' ? 'caretaker-selected' : ''}`}
                             onClick={() => setFormData({ ...formData, gender: 'Male' })}>
                            Male
                        </div>
                        <div className={`caretaker-genderOption ${formData.gender === 'Female' ? 'caretaker-selected' : ''}`}
                             onClick={() => setFormData({ ...formData, gender: 'Female' })}>
                            Female
                        </div>
                    </div>
                    <div className="caretaker-inputRow">
                        <input
                            className="caretaker-inputField"
                            type="date"
                            name="birthDate"
                            value={formData.birthDate}
                            onChange={handleChange}
                        />
                    </div>
                    <div className="caretaker-inputRow">
                        <input
                            className="caretaker-inputField"
                            type="email"
                            placeholder="Email"
                            name="email"
                            required
                            value={formData.email}
                            onChange={handleChange}
                        />
                    </div>
                    <div className="caretaker-inputRow caretaker-phoneRow">

                        <input
                            className="caretaker-inputField caretaker-phoneNumber"
                            type="tel"
                            placeholder="Phone Number"
                            name="phoneNumber"
                            required
                            value={formData.phoneNumber}
                            onChange={handleChange}
                        />
                    </div>
                    <div className="caretaker-inputRow">
                        <input
                            className="caretaker-inputField"
                            type="password"
                            placeholder="Enter Password"
                            name="password"
                            maxLength="20"
                            required
                            value={formData.password}
                            onChange={handleChange}
                        />
                    </div>
                    <div className="caretaker-buttonRow">
                        <button type="submit" className="caretaker-button caretaker-submitButton">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    );
}

export default CaretakerRegistration;
