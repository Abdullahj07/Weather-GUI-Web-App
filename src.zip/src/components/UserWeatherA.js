//USER WEATHER PAGE FOR PATIENTS WITH ARTHRITIS
//Import libraries and links for the document
import React, { useState, useEffect } from 'react'; //For react
import axios from 'axios'; // For HTTP requests
import { useNavigate } from 'react-router-dom'; //For navigation
import './UserWeather.css'; //Link to stylesheet

//Import icons for weather conditions
import ClearIcon from './assets/clear.svg';
import CloudyIcon from './assets/cloudy.svg';
import DrizzleIcon from './assets/drizzle.svg';
import RainIcon from './assets/rain.svg';
import SnowIcon from './assets/snow.svg';
import HazeIcon from './assets/haze.svg';
import MistIcon from './assets/mist.svg';
import ThunderIcon from './assets/thunderstorms.svg';

//Import patient images for nav bar
import p1 from './p1.png';
import p2 from './p2.png';
import p3 from './p3.png';
import p4 from './p4.png';
import p5 from './p5.png';
import p6 from './p6.png';

const UserWeatherPage = () => {
    // Manage the component state
    const [weatherData, setWeatherData] = useState(null); // Stores fetched data from API
    const [loc, setLoc] = useState(localStorage.getItem('userLocation') || 'London'); // Use stored location or default to London
    const [isSidebarOpen, setIsSidebarOpen] = useState(false); // Controls the nav bar's visibility
    const [error, setError] = useState(''); // State to handle API errors, including location not found
    const YOUR_API_KEY = 'a6d7a7156c8fe3c3831451402843be24'; // My open weather API key
    const YOUR_GOOGLE_PLACES_API_KEY = 'AIzaSyBNRXr_GCVbVAS5FrHFq279atpfNWoe9Qk';//My Google places API key
    const [parksData, setParksData] = useState([]);
    const [showParks, setShowParks] = useState(false); // New state to toggle park suggestions

    const navigate = useNavigate();
    //Checks if sidebar is open
    const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);
    //Checks setsShowParks toggle
    const toggleParks = () => setShowParks(!showParks);
    const handleLogout = () => navigate('/Login');

    useEffect(() => {
        const fetchWeather = async () =>
        {
            //Get url for open weather api info
            const url = `https://api.openweathermap.org/data/2.5/weather?q=${loc}&appid=${YOUR_API_KEY}&units=metric`;
            try {
                const response = await axios.get(url);
                setWeatherData(response.data);
                setError('');
                //Pass location to fetchparks function
                fetchParks(loc);
            } catch (error) {
                console.error("Error fetching data:", error);
                setError('Location was not found.');
            }
        };
        fetchWeather();
    }, [loc]);
    //Function to fetchParks, uses google location api, returns top 5 results
    const fetchParks = async (locationString) => {
        const parksUrl = `https://maps.googleapis.com/maps/api/place/textsearch/json?query=parks+in+${locationString}&key=${YOUR_GOOGLE_PLACES_API_KEY}`;
        try {
            const response = await axios.get(parksUrl);
            const parks = response.data.results.slice(0, 5); // Limit to 5 parks
            setParksData(parks);
        } catch (error) {
            console.error("Error fetching parks data:", error);
        }
    };


    //used to fetch related image from the Google places api
    const buildPhotoUrl = (photoReference) => {
        return `https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=${photoReference}&key=${YOUR_GOOGLE_PLACES_API_KEY}`;
    };
    //Used to ensure the first letter of a string is capital
    const capitalizeFirstLetter = (string) => string.charAt(0).toUpperCase() + string.slice(1);


    //Limit the weather condition to only 2 words stops design overflow
    const formatWeatherCondition = (description) => {
        const words = description.split(' ').slice(0, 2); // Limit to first two words
        return words.map(capitalizeFirstLetter).join(' ');
    };
    //Function to link weather with corresponding icon
    const getWeatherIcon = (condition) => {
        switch (condition) {
            case 'Clear': return ClearIcon;
            case 'Clouds': return CloudyIcon;
            case 'Drizzle': return DrizzleIcon;
            case 'Rain': return RainIcon;
            case 'Snow': return SnowIcon;
            case 'Haze': return HazeIcon;
            case 'Mist': return MistIcon;
            case 'Thunderstorm': return ThunderIcon;
            default: return CloudyIcon;
        }
    };



    //Function with decided the colour for that day
    //In this case it is the conditions for ARTHRITIS
    //if its cold or poor conditions the user will be given a red light
    //If it's cloudy or light rain they are given amber
    ///Else it is green
    const decideAdviceAndColor = (temp, condition) => {
        if (temp < 10 || condition === 'Rain' || condition === 'Snow') {
            return { color: 'weather-red', advice: "Stay warm and avoid going outside to prevent joint pain due to cold and wet conditions." };
        } else if (condition === 'Clouds' || condition === 'Drizzle') {
            return { color: 'weather-amber', advice: "Be cautious if you need to go outside, as damp conditions may lead to discomfort." };
        } else {
            return { color: 'weather-green', advice: "Weather conditions appear to be gentle today. Enjoy your activities, but always be mindful of your joints." };
        }
    };

    return (
        <div className="weather-userWeatherPage">
            <button onClick={toggleSidebar} className="weather-burgerIcon">☰</button>
            <div className={`weather-navSidebar ${isSidebarOpen ? 'open' : ''}`}>
                <h2>Hi there, select another patient</h2>
                <div className="weather-patientsGrid">
                    {[
                        {name: 'Alex', image: p1, weatherPage: '/UserWeatherA'},
                        {name: 'Jordan', image: p2, weatherPage: '/UserWeatherH'},
                        {name: 'Taylor', image: p3, weatherPage: '/UserWeatherN'},
                        {name: 'Casey', image: p4, weatherPage: '/UserWeatherR'},
                        {name: 'Morgan', image: p5, weatherPage: '/UserWeatherS'},
                        {name: 'Charlie', image: p6, weatherPage: '/UserWeatherA'},
                    ].map((patient, index) => (
                        <div key={index} className="weather-patientCircle"
                             onClick={() => navigate(patient.weatherPage)}>
                            <img src={patient.image} alt={patient.name}/>
                            <div className="weather-patientNameBox">{patient.name}</div>
                        </div>
                    ))}
                </div>
                <button onClick={handleLogout} className="weather-button weather-logoutButton">Logout</button>
                <button onClick={() => navigate('/Splash')} className="weather-button weather-menuButton">Back to Menu</button>
            </div>
            {weatherData ? (
                <>
                    <div className={`weather-weatherCircle ${decideAdviceAndColor(weatherData.main.temp, weatherData.weather[0].main).color}`}>
                        <div className="weather-temperature">{Math.round(weatherData.main.temp)}°C</div>
                        <img src={getWeatherIcon(weatherData.weather[0].main)} alt="Weather icon" className="weather-weatherIcon"/>
                        <div className="weather-weatherCondition">{formatWeatherCondition(weatherData.weather[0].description)}</div>
                    </div>
                    <button onClick={toggleParks} className="weather-button weather-parkButton">Want some ideas on where to go?</button>
                    {showParks && (
                        <div className="weather-parkSuggestions">
                            <h3>Local Parks</h3>
                            {parksData.length > 0 ? parksData.map((park, index) => (
                                <div key={index} className="weather-parkDetail">
                                    {park.photos && park.photos.length > 0 && (
                                        <img src={buildPhotoUrl(park.photos[0].photo_reference)} alt={park.name} className="weather-parkImage"/>
                                    )}
                                    <div className="weather-parkInfo">
                                        <h4>{park.name}</h4>
                                        <p>{park.formatted_address}</p>
                                        {park.rating && <p>Rating: {park.rating} / 5</p>}
                                    </div>
                                </div>
                            )) : (
                                <p>No parks found.</p>
                            )}
                        </div>
                    )}
                    <div className="weather-adviceText">{decideAdviceAndColor(weatherData.main.temp, weatherData.weather[0].main).advice}</div>
                </>
            ) : (
                <div>Loading...</div> // Display while weather data is loading
            )}
        </div>
    );
};

export default UserWeatherPage; //Export for use
