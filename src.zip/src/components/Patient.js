//Vital imports for function
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Patient.css';
//Component for patient registration
function PatientRegistration() {
    //Initialize state with an object for patient details
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        age: '',
        gender: '',
        disability: '',
    });
    //Track if form has been submitted
    const [isSubmitted, setIsSubmitted] = useState(false);
    //Call navigation functionality
    const navigate = useNavigate();

    //Handle changes in inputs
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prevState => ({
            ...prevState,
            [name]: value//Updates property in form data
        }));
    };
    //Handle submission
    const handleSubmit = (event) => {
        event.preventDefault();//Prevents default action
        console.log(formData);

        setIsSubmitted(true);//Sets submitted as true
        //After 2 seconds nav to splash page
        setTimeout(() => {
            navigate('/Splash');
        }, 2000);
    };
    //Render the JSX for the registration page, displays am message at the top once a patient has been successfully registers
    //Creates form for registration
    return (
        <div className="container">
            <div className="formContainer">
                <div className="title">Register a Patient</div>
                {isSubmitted && <div className="successMessage">Patient successfully added.</div>}
                <form onSubmit={handleSubmit}>
                    <div className="inputContainer">
                        <input
                            type="text"
                            className="inputField"
                            placeholder="First Name"
                            name="firstName"
                            required
                            value={formData.firstName}
                            onChange={handleChange}
                        />
                    </div>
                    <div className="inputContainer">
                        <input
                            type="text"
                            className="inputField"
                            placeholder="Last Name"
                            name="lastName"
                            required
                            value={formData.lastName}
                            onChange={handleChange}
                        />
                    </div>
                    <div className="inputContainer">
                        <input
                            type="number"
                            className="inputField"
                            placeholder="Age"
                            name="age"
                            required
                            value={formData.age}
                            onChange={handleChange}
                        />
                    </div>
                    <div className="inputContainer">
                        <div className="formSectionTitle">Select your gender:</div>
                        <div className="radioGroup">
                            <div className={`radioOption ${formData.gender === 'Male' ? 'selected' : ''}`} onClick={() => setFormData({ ...formData, gender: 'Male' })}>Male</div>
                            <div className={`radioOption ${formData.gender === 'Female' ? 'selected' : ''}`} onClick={() => setFormData({ ...formData, gender: 'Female' })}>Female</div>
                        </div>
                    </div>
                    <div className="inputContainer">
                        <div className="formSectionTitle">Select a disability:</div>
                        <div className="radioGroup">
                            <div className={`radioOption ${formData.disability === 'Arthritis' ? 'selected' : ''}`} onClick={() => setFormData({ ...formData, disability: 'Arthritis' })}>Arthritis</div>
                            <div className={`radioOption ${formData.disability === 'Heart Disease' ? 'selected' : ''}`} onClick={() => setFormData({ ...formData, disability: 'Heart Disease' })}>Heart Disease</div>
                            <div className={`radioOption ${formData.disability === 'Respiratory Illness' ? 'selected' : ''}`} onClick={() => setFormData({ ...formData, disability: 'Respiratory Illness' })}>Respiratory Illness</div>
                            <div className={`radioOption ${formData.disability === 'Stroke Victim' ? 'selected' : ''}`} onClick={() => setFormData({ ...formData, disability: 'Stroke Victim' })}>Stroke Victim</div>
                            <div className={`radioOption ${formData.disability === 'Nervous System Disorder' ? 'selected' : ''}`} onClick={() => setFormData({ ...formData, disability: 'Nervous System Disorder' })}>Nervous System Disorder</div>
                        </div>
                    </div>
                    <div className="buttonRow">
                        <button type="submit" className="button submitButton">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    );
}

export default PatientRegistration;
