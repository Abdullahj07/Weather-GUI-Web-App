//Import modules and components needed
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Login.css';

//Login function
function Login() {
    const [username, setUsername] = useState('');//Hold username
    const [password, setPassword] = useState('');//Hold password
    const [inputError, setInputError] = useState(false);//Tracks input error
    const navigate = useNavigate();//Allows navigation

    //handle login is called when the form is submitted
    const handleLogin = (event) => {
        event.preventDefault();
        //Dummy data change for backend
        if (username === 'admin' && password === 'password') {
            setInputError(false);
            navigate('/Splash');//Is login found nav to splash page
        } else {//Else set error state
            setInputError(true);
        }
    };
    //Render for page of login form, sets classes for styling, and handles error, if the user wants to register nav to
    //register page
    return (
        <div className="login-container">
            <div className="login-formContainer">
                <div className="login-titleContainer">
                    <div className="login-title login-green"><i>Green</i>Go</div>
                    <div className="login-title login-red"><i>Red</i>No</div>
                </div>
                <form onSubmit={handleLogin}>
                    <div className="login-inputRow">
                        <div className="login-inputContainer">
                            <input
                                className={inputError ? 'login-inputField login-error' : 'login-inputField'}
                                placeholder="Username"
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                            />
                        </div>
                    </div>
                    <div className="login-inputRow">
                        <div className="login-inputContainer">
                            <input
                                className={inputError ? 'login-inputField login-error' : 'login-inputField'}
                                type="password"
                                placeholder="Password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                            />
                        </div>
                    </div>
                    <div className="login-buttonRow">
                        <button type="submit" className="login-button login-loginButton">Login</button>
                        <button type="button" className="login-button login-registerButton" onClick={() => navigate('/Register')}>
                            Register
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}

export default Login;
