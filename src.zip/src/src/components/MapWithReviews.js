import React, { useEffect, useState } from 'react';
import './MapWithReviews.css';

const MapWithReviews = () => {
  const [mapError, setMapError] = useState(null);

  useEffect(() => {
    let infowindow;

    const initMap = () => {
      const mileEndLondon = new window.google.maps.LatLng(51.5255, -0.0395);

      const map = new window.google.maps.Map(document.getElementById('map'), {
        center: mileEndLondon,
        zoom: 15
      });

      const request = {
        location: mileEndLondon,
        radius: '1000',
        type: ['park']
      };

      const service = new window.google.maps.places.PlacesService(map);
      service.nearbySearch(request, callback);

      function callback(results, status) {
        if (status === window.google.maps.places.PlacesServiceStatus.OK) {
          for (let i = 0; i < results.length; i++) {
            createMarker(results[i]);
          }
        } else {
          setMapError('Failed to fetch nearby places. Please try again later.');
        }
      }

      function createMarker(place) {
        const marker = new window.google.maps.Marker({
          map: map,
          position: place.geometry.location,
          title: place.name
        });

        marker.addListener('mouseover', function() {
          infowindow = new window.google.maps.InfoWindow({
            content: `
              <div>
                <img src="${place.icon}" alt="${place.name}" style="width: 50px; height: 50px;">
                <h2>${place.name}</h2>
                <p>Rating: ${place.rating}</p>
                <p>Reviews: ${place.user_ratings_total}</p>
              </div>
            `
          });
          infowindow.open(map, marker);
        });

        marker.addListener('mouseout', function() {
          infowindow.close();
        });

        window.google.maps.event.addListener(marker, 'click', function() {
          window.open(`https://www.google.com/maps/place/?q=place_id:${place.place_id}&view=ratings`, '_blank');
        });
      }
    };

    if (!window.google) {
      const script = document.createElement('script');
      script.src = `https://maps.googleapis.com/maps/api/js?key=AIzaSyBaHs1jaHKsqUL6QLf3MBE0QQoyyVTs03Y&libraries=places&callback=initMap`;
      script.async = true;
      script.defer = true;
      script.onerror = () => {
        setMapError('Failed to load Google Maps API. Please check your internet connection.');
      };
      document.head.appendChild(script);
    } else {
      initMap();
    }
  }, []);

  return (
    <div id="map-container">
      {mapError ? (
        <div className="error-message">{mapError}</div>
      ) : (
        <div id="map"></div>
      )}
    </div>
  );
};

export default MapWithReviews;
