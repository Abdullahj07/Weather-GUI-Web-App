import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';

import Login from './components/Login';
import Register from './components/Register';
import Patient from './components/Patient';
import Splash from './components/Splash';
import UserWeatherA from './components/UserWeatherA';
import UserWeatherH from "./components/UserWeatherH";
import UserWeatherN from "./components/UserWeatherN";
import UserWeatherR from "./components/UserWeatherR";
import UserWeatherS from "./components/UserWeatherS";

function App() {
    return (
        <Router>
            <div>
                {/* Navigation can be added here if needed */}
                {/* Routing */}
                <Routes>
                    <Route path="/" element={<Navigate replace to="/login" />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="/register" element={<Register />} />
                    <Route path="/patient" element={<Patient />} />
                    <Route path="/splash" element={<Splash />} />
                    <Route path="/userWeatherA" element={<UserWeatherA />} />
                    <Route path="/userWeatherH" element={<UserWeatherH />} />
                    <Route path="/userWeatherN" element={<UserWeatherN />} />
                    <Route path="/userWeatherR" element={<UserWeatherR />} />
                    <Route path="/userWeatherS" element={<UserWeatherS />} />
                </Routes>
            </div>
        </Router>
    );
}

export default App;
